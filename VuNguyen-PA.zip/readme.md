# MacOS
I coded and tested run on my Macbook. Just want to note that to address if there will be any compatibility issues.

# Simulator output issue
I ran into a issue that when I ran the project-test.pl file, it only output e-remove folder in the test-outputs
As I observed, it did create simulate folder too but somehow got wiped after running. And It also
created simulate output files too, since comments.txt showed that.
